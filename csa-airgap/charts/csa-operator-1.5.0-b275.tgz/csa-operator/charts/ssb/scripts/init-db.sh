#!/bin/bash

# Copyright (c) 2025 Cloudera, Inc. All rights reserved.
#
# This code is provided to you pursuant to your written agreement with Cloudera, which may be the terms of the
# Affero General Public License version 3 (AGPLv3), or pursuant to a written agreement with a third party authorized
# to distribute this code.  If you do not have a written agreement with Cloudera or with an authorized and
# properly licensed third party, you do not have any rights to this code.
#
# If this code is provided to you under the terms of the AGPLv3:
#   (A) CLOUDERA PROVIDES THIS CODE TO YOU WITHOUT WARRANTIES OF ANY KIND;
#   (B) CLOUDERA DISCLAIMS ANY AND ALL EXPRESS AND IMPLIED WARRANTIES WITH RESPECT TO THIS CODE, INCLUDING BUT NOT
#   LIMITED TO IMPLIED WARRANTIES OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE;
#   (C) CLOUDERA IS NOT LIABLE TO YOU, AND WILL NOT DEFEND, INDEMNIFY, OR HOLD YOU HARMLESS FOR ANY CLAIMS ARISING
#   FROM OR RELATED TO THE CODE; AND
#   (D) WITH RESPECT TO YOUR EXERCISE OF ANY RIGHTS GRANTED TO YOU FOR THE CODE, CLOUDERA IS NOT LIABLE FOR ANY
#   DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE OR CONSEQUENTIAL DAMAGES INCLUDING, BUT NOT LIMITED
#   TO, DAMAGES RELATED TO LOST REVENUE, LOST PROFITS, LOSS OF INCOME, LOSS OF BUSINESS ADVANTAGE OR
#   UNAVAILABILITY, OR LOSS OR CORRUPTION OF DATA.

until pg_isready
do
  echo "Waiting for Postgres to start..."
  sleep 1
done

echo "Postgres is ready"
echo "Starting user and database initialization..."
current_user=$(id -un)
pg_user_exists=$(psql -U $POSTGRES_USER -c "SELECT count(*) FROM pg_catalog.pg_user WHERE usename = '${current_user}';" -t | tr -d '[:space:]')
pg_database_exists=$(psql -U $POSTGRES_USER -c "SELECT count(*) FROM pg_database WHERE datname = '${current_user}';" -t | tr -d '[:space:]')

if [[ "$pg_user_exists" -gt 0 ]]
then
  echo "Postgres user '${current_user}' already exists"
else
  createuser -U $POSTGRES_USER -s ${current_user}
  echo "Postgres user '${current_user}' was created"
fi

if [[ "$pg_database_exists" -gt 0 ]]
then
  echo "Database '${current_user}' already exists"
else
  createdb -U ${current_user} ${current_user}
  echo "Postgres database '${current_user}' was created"
fi

echo "User and database initialization finished"
