# Copyright (c) 2024-2026 Cloudera, Inc. All rights reserved.
#
# This code is provided to you pursuant to your written agreement with Cloudera, which may be the terms of the
# Affero General Public License version 3 (AGPLv3), or pursuant to a written agreement with a third party authorized
# to distribute this code.  If you do not have a written agreement with Cloudera or with an authorized and
# properly licensed third party, you do not have any rights to this code.
#
# If this code is provided to you under the terms of the AGPLv3:
#   (A) CLOUDERA PROVIDES THIS CODE TO YOU WITHOUT WARRANTIES OF ANY KIND;
#   (B) CLOUDERA DISCLAIMS ANY AND ALL EXPRESS AND IMPLIED WARRANTIES WITH RESPECT TO THIS CODE, INCLUDING BUT NOT
#   LIMITED TO IMPLIED WARRANTIES OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE;
#   (C) CLOUDERA IS NOT LIABLE TO YOU, AND WILL NOT DEFEND, INDEMNIFY, OR HOLD YOU HARMLESS FOR ANY CLAIMS ARISING
#   FROM OR RELATED TO THE CODE; AND
#   (D) WITH RESPECT TO YOUR EXERCISE OF ANY RIGHTS GRANTED TO YOU FOR THE CODE, CLOUDERA IS NOT LIABLE FOR ANY
#   DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE OR CONSEQUENTIAL DAMAGES INCLUDING, BUT NOT LIMITED
#   TO, DAMAGES RELATED TO LOST REVENUE, LOST PROFITS, LOSS OF INCOME, LOSS OF BUSINESS ADVANTAGE OR
#   UNAVAILABILITY, OR LOSS OR CORRUPTION OF DATA.

{/*
Expand the name of the chart.
*/}}
{{- define "ssb.name" -}}
{{- .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ssb.fullname" -}}
{{- if contains .Chart.Name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name .Chart.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ssb.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ssb.labels" -}}
helm.sh/chart: {{ include "ssb.chart" . }}
{{ include "ssb.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ssb.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ssb.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "ssb.serviceAccountName" -}}
{{- if .Values.ssbServiceAccount.create }}
{{- default (include "ssb.fullname" .) .Values.ssbServiceAccount.name }}
{{- else }}
{{- default "default" .Values.ssbServiceAccount.name }}
{{- end }}
{{- end }}


{{/*
Get images of deployments
*/}}
{{- define "ssb.sse.imagePath" -}}
{{- if .Values.sse.image.digest }}
{{- .Values.sse.image.repository }}{{ if .Values.hadoopConfiguration.enabled }}-hadoop{{- end}}@{{ .Values.sse.image.digest }}
{{- else }}
{{- .Values.sse.image.repository }}{{ if .Values.hadoopConfiguration.enabled }}-hadoop{{- end}}:{{ .Values.sse.image.tag | default .Chart.AppVersion }}
{{- end }}
{{- end }}

{{- define "ssb.flink-extended.imagePath" -}}
{{- if .Values.sqlRunner.image.digest }}
{{- .Values.sqlRunner.image.repository }}{{ if .Values.hadoopConfiguration.enabled }}-hadoop{{- end}}@{{ .Values.sqlRunner.image.digest }}
{{- else }}
{{- .Values.sqlRunner.image.repository }}{{ if .Values.hadoopConfiguration.enabled }}-hadoop{{- end}}:{{ .Values.sqlRunner.image.tag | default .Chart.AppVersion }}
{{- end }}
{{- end }}

{{- define "ssb.postgres.imagePath" -}}
{{- if .Values.database.image.digest }}
{{- .Values.database.image.repository }}@{{ .Values.database.image.digest }}
{{- else }}
{{- .Values.database.image.repository }}:{{ .Values.database.image.tag }}
{{- end }}
{{- end }}

{{- define "ssb.mve.imagePath" -}}
{{- if .Values.mve.image.digest }}
{{- .Values.mve.image.repository }}@{{ .Values.mve.image.digest }}
{{- else }}
{{- .Values.mve.image.repository }}:{{ .Values.mve.image.tag | default .Chart.AppVersion }}
{{- end }}
{{- end }}

{{- define "ssb.sse.admins"}}
{{- if eq "basic" .Values.userManagement.type }}
{{- $usersStr := "" }}
{{- range $i, $user := .Values.userManagement.basic.users }}
{{- if $user.isAdmin }}
{{- $usersStr = print $usersStr $user.name "," }}
{{- end }}
{{- end }}
{{- $usersStr | trimSuffix "," }}
{{- else if eq "ldap" .Values.userManagement.type }}
{{- $adminsStr := "" }}
{{- range $i, $user := .Values.userManagement.ldap.admins }}
{{- $adminsStr = print $adminsStr $user "," }}
{{- end }}
{{- $adminsStr | trimSuffix "," }}
{{- end }}
{{- end }}

{{- define "default-pod-volumes" }}
{{- if .Values.hadoopConfiguration.enabled }}
- name: hadoop-conf-volume
  configMap:
    name: {{ .Values.hadoopConfiguration.hadoop.configMapRef }}
{{- if .Values.hadoopConfiguration.hive.configMapRef }}
- name: hive-conf-volume
  configMap:
    name: {{ .Values.hadoopConfiguration.hive.configMapRef }}
{{- end }}
{{- end }}
{{- if .Values.kerberosConfiguration.configMapRef }}
- name: krb5-conf-volume
  configMap:
    name: {{ .Values.kerberosConfiguration.configMapRef }}
{{- end }}
{{- if .Values.kerberosConfiguration.serviceKeytabSecretRef }}
- name: service-keytab-volume
  secret:
    secretName: {{ .Values.kerberosConfiguration.serviceKeytabSecretRef }}
{{- end }}
{{- end }}

{{- define "default-pod-volume-mounts" }}
{{- if .Values.hadoopConfiguration.enabled }}
- name: hadoop-conf-volume
  mountPath: /etc/hadoop/conf
  readOnly: true
{{- if .Values.hadoopConfiguration.hive.configMapRef }}
- name: hive-conf-volume
  mountPath: /etc/hive/conf
  readOnly: true
{{- end }}
{{- end }}
{{- if .Values.kerberosConfiguration.configMapRef }}
- name: krb5-conf-volume
  mountPath: /etc/krb5.conf
  subPath: krb5.conf
  readOnly: true
{{- end }}
{{- if .Values.kerberosConfiguration.configMapRef }}
- name: service-keytab-volume
  mountPath: /opt/cloudera/ssb-sse/service.keytab
  subPath: service.keytab
  readOnly: true
{{- end }}
{{- end }}
